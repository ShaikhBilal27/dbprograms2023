# Add new column "purpose varchar(50)" to the mobiles table using alter query

import pymysql
con=pymysql.connect(host='b2wm8fraedv80ljndd2y-mysql.services.clever-cloud.com',user='uzn4xgnnasdz7vxw',passwd='4FcAsYhq4bJxfSXeznzu',database='b2wm8fraedv80ljndd2y')

curs=con.cursor()

altqry = "ALTER TABLE MOBILES ADD purpose VARCHAR(50)"
curs.execute(altqry)

con.close()