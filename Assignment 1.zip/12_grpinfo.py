#🤯🤯🤯


import pymysql
con=pymysql.connect(host='b2wm8fraedv80ljndd2y-mysql.services.clever-cloud.com',user='uzn4xgnnasdz7vxw',passwd='4FcAsYhq4bJxfSXeznzu',database='b2wm8fraedv80ljndd2y')

curs=con.cursor()

# group_by_query = """
#     SELECT brand,
#            COUNT(model_name) AS total_models,
#            AVG(price) AS average_price,
#            AVG(rating) AS average_rating
#     FROM MOBILES
#     GROUP BY brand
# """
# curs.execute(group_by_query)

curs.execute("select * from MOBILES")
data=curs.fetchall()
print(data)                       
if data:
    print("Group-by Information:")
    print("Brand\t\tTotal Models\tAverage Price\tAverage Rating")
    for row in data:
        brand, total_models, average_price, average_rating = row
        print(f"{brand}\t\t{total_models}\t\t{average_price:.2f}\t\t{average_rating:.2f}")
else:
    print("No data found.")

con.close()