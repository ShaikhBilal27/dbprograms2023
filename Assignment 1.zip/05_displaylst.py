import pymysql

con=pymysql.connect(host='b2wm8fraedv80ljndd2y-mysql.services.clever-cloud.com',user='uzn4xgnnasdz7vxw',passwd='4FcAsYhq4bJxfSXeznzu',database='b2wm8fraedv80ljndd2y')

curs=con.cursor()

comp=(input('Enter the company : '))

curs.execute("Select PRICE from MOBILES where company=%s" %comp)
data=curs.fetchall()
if data:
    print(data)
else:
    print('Data not Found')

con.close()