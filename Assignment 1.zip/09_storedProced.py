#skBilal😎

import pymysql
con=pymysql.connect(host='b2wm8fraedv80ljndd2y-mysql.services.clever-cloud.com',user='uzn4xgnnasdz7vxw',passwd='4FcAsYhq4bJxfSXeznzu',database='b2wm8fraedv80ljndd2y')

curs=con.cursor()
try:
    prodid = int(input("Enter the product ID: "))
    Reduce_amt = int(input("Enter the reduction amount: "))

    curs.callproc("ReducePrice", [prodid, Reduce_amt])

except Exception as err:
    print(err)

# delimiter //

# create procedure ReducePrice(prdid INT, Reduce_amt INT)
# begin
# UPDATE MOBILES
# SET price=price - Reduce_amt;
# WHERE prodid=prdid;
# end//

# delimiter;
 