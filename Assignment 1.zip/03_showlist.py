# Write a program to show list of all mobiles
# SELECT * FROM MOBILES;

import pymysql

con=pymysql.connect(host='b2wm8fraedv80ljndd2y-mysql.services.clever-cloud.com',user='uzn4xgnnasdz7vxw',passwd='4FcAsYhq4bJxfSXeznzu',database='b2wm8fraedv80ljndd2y')

curs=con.cursor()

curs.execute("select * from MOBILES")
data=curs.fetchall()
print(data)
con.close()
