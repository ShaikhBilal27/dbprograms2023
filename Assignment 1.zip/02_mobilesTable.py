# Write a program to take new mobile data as input and add mobile to the DB table
#SKBILAL
import pymysql

try:
    con=pymysql.connect(host='b2wm8fraedv80ljndd2y-mysql.services.clever-cloud.com',user='uzn4xgnnasdz7vxw',passwd='4FcAsYhq4bJxfSXeznzu',database='b2wm8fraedv80ljndd2y')
    curs=con.cursor()

    prodid = int(input("Enter Product ID: "))
    modelname = input("Enter Model Name: ")
    company = input("Enter Company: ")
    connectivity = input("Enter Connectivity (4G/5G): ")
    ram = int(input("Enter RAM (in GB): "))
    rom = int(input("Enter ROM (in GB): "))
    color = input("Enter Color: ")
    screen = input("Enter Screen Type: ")
    battery = int(input("Enter Battery Capacity (in mAh): "))
    processor = input("Enter Processor: ")
    price = int(input("Enter Price: "))
    rating = float(input("Enter Rating: "))
    purpose=input("Enter the Purpose : ")
    curs.execute("insert into MOBILES values (%d, %s, %s, %s, %d, %d, %s, %s, %d, %s, %d, %f,%s)"%(prodid, modelname, company, connectivity, ram, rom, color, screen, battery, processor, price, rating, purpose))
    con.commit()
    print('New Mobile added in the table ----')
    curs.execute("select * from MOBILES")
    data=curs.fetchall()
    print(data)          
    

except Exception as err:
    print('Error as : ', err)


con.close()
