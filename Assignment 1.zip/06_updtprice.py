import pymysql

con=pymysql.connect(host='b2wm8fraedv80ljndd2y-mysql.services.clever-cloud.com',user='uzn4xgnnasdz7vxw',passwd='4FcAsYhq4bJxfSXeznzu',database='b2wm8fraedv80ljndd2y')
curs=con.cursor()

try:
    prd=int(input('Enter the Prodid To update the Price : '))

    curs.execute("select * from MOBILES where prodid=%d" %prd)
    data=curs.fetchone()

    if data:
        print(data)
        newpr=int(input('Enter new Price : '))
        curs.execute("update MOBILES set price='%d' where prodid=%d" %(newpr,prd))
        con.commit()
        print('New price updated successfully')
    else:
        print('Mobile does not exist')
except:
    print('Error')

con.close()