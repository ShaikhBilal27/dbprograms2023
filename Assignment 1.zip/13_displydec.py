import pymysql
con=pymysql.connect(host='b2wm8fraedv80ljndd2y-mysql.services.clever-cloud.com',user='uzn4xgnnasdz7vxw',passwd='4FcAsYhq4bJxfSXeznzu',database='b2wm8fraedv80ljndd2y')

curs=con.cursor()

rom=int(input('Enter the rom : '))

# qry= 'SELECT * FROM MOBILES where rom=%d ' %rom
curs.execute('SELECT * FROM MOBILES where rom=%d ORDER by DECS' %rom)
data = curs.fetchall()
print(data)
if data:
    print("Mobiles sorted in descending order of the Rom:")
    for row in data:
        print(row)
else:
    print("No data found.")

con.close()

# curs.execute("select * from MOBILES where prodid=%d" %prod)
# data=curs.fetchone()