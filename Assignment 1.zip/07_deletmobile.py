import pymysql

con=pymysql.connect(host='b2wm8fraedv80ljndd2y-mysql.services.clever-cloud.com',user='uzn4xgnnasdz7vxw',passwd='4FcAsYhq4bJxfSXeznzu',database='b2wm8fraedv80ljndd2y')
curs=con.cursor()

try:
    prod=int(input('Enter Prodid to delete : '))
    curs.execute("select * from MOBILES where prodid=%d" %prod)
    data=curs.fetchone()

    if data:
        print(data)
        cho=input('Do you really want to delete? (yes/no) : ')
        if cho.lower()=='yes':
            curs.execute("delete from MOBILES where prodid=%d" %prod)
            con.commit()
            print('Mobile deleted successfully')
        else:
            print('Deletion Abord')
    else:
        print('account does not exist')
except Exception as err:
    print('Error as : ', err)

con.close()