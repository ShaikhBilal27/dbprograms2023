# Write a program to accept modelname and purpose, update allmobiles of the model with the purpose ( gaming/office/social/Coding😎 etc.)
#skBilal😎
import pymysql

con=pymysql.connect(host='b2wm8fraedv80ljndd2y-mysql.services.clever-cloud.com',user='uzn4xgnnasdz7vxw',passwd='4FcAsYhq4bJxfSXeznzu',database='b2wm8fraedv80ljndd2y')
curs=con.cursor()

try:
    modlnm=input('Enter the Modelname : ')

    curs.execute("select * from MOBILES where modelname=%s" %modlnm)
    data=curs.fetchone()

    if data:
        print(data)
        purps=input('Enter the Purpose : ')
        curs.execute("update MOBILES set purpose=%s where modelname=%s" %(purps,modlnm))
        con.commit()
        print('Purpose updated successfully')
    else:
        print('Mobile does not exist')
except Exception as err:
    print('Error as',err)

con.close()