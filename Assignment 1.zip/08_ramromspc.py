import pymysql
con=pymysql.connect(host='b2wm8fraedv80ljndd2y-mysql.services.clever-cloud.com',user='uzn4xgnnasdz7vxw',passwd='4FcAsYhq4bJxfSXeznzu',database='b2wm8fraedv80ljndd2y')

curs=con.cursor()

ram=int(input('Enter the ram : '))
rom=int(input('Enter the rom : '))

curs.execute("Select * from MOBILES where ram=%d AND rom=%d" %(ram,rom))
data=curs.fetchall()
if data:
    print("Mobiles with the specified RAM-ROM combination:")
    for result in data:
        print(result)
else:
    print("No mobiles found with the specified RAM-ROM combination.")

con.close()